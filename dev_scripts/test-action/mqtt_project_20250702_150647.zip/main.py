#!/usr/bin/env python3
import os
import time
import json
import logging
import threading
from datetime import datetime, timedelta

import paho.mqtt.client as mqtt
from dotenv import load_dotenv

# Load connection settings
load_dotenv()
MQTT_HOST = os.getenv("MQTT_HOST", "localhost")
MQTT_PORT = int(os.getenv("MQTT_PORT", 1883))
MQTT_USER = os.getenv("MQTT_USER")
MQTT_PASS = os.getenv("MQTT_PASS")

# Setup logging to file with timestamps
logging.basicConfig(
    filename="mqtt_debug.log",
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s %(message)s"
)

# Session manager for grouping messages within 50s of each published event
class SessionManager:
    def __init__(self, window=50):
        self.window = timedelta(seconds=window)
        self.lock = threading.Lock()
        self.sessions = []  # list of dicts: {'event_cnt', 'start', 'messages'}

    def start_session(self, event_cnt):
        with self.lock:
            self.sessions.append({
                "event_cnt": event_cnt,
                "start": datetime.now(),
                "messages": []
            })

    def record(self, topic, payload):
        now = datetime.now()
        with self.lock:
            for sess in list(self.sessions):
                if now - sess["start"] <= self.window:
                    sess["messages"].append({
                        "timestamp": now.isoformat(),
                        "topic": topic,
                        "payload": payload
                    })
                else:
                    # window expired → flush
                    logging.info(
                        f"Session {sess['event_cnt']} grouped {len(sess['messages'])} messages:\n"
                        + "\n".join(
                            f"  [{m['timestamp']}] {m['topic']} → {m['payload']}"
                            for m in sess["messages"]
                        )
                    )
                    self.sessions.remove(sess)

sess_mgr = SessionManager(window=50)

# MQTT callbacks
def on_connect(client, userdata, flags, rc):
    logging.info(f"Connected to {MQTT_HOST}:{MQTT_PORT} (rc={rc})")
    subs = [
        ("shellies/switch-0081F2/relay/#", 0),
        ("actions/#", 0),
        ("cameras/HIK-B640HA-0001/snapshot", 0),
        ("storage/#", 0),
    ]
    client.subscribe(subs)
    logging.info("Subscribed to topics: " + ", ".join(t for t, _ in subs))

def on_message(client, userdata, msg):
    payload = msg.payload.decode(errors="ignore")
    logging.info(f"RECV {msg.topic} → {payload}")
    sess_mgr.record(msg.topic, payload)

def publish_event(client, event, topic="shellies/switch-0081F2/input_event/1"):
    payload = json.dumps(event)
    client.publish(topic, payload)
    logging.info(f"SENT {topic} → {payload}")
    sess_mgr.start_session(event.get("event_cnt"))

def main():
    client = mqtt.Client()
    client.username_pw_set(MQTT_USER, MQTT_PASS)
    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(MQTT_HOST, MQTT_PORT, keepalive=60)
    client.loop_start()

    try:
        while True:
            # publish every minute
            publish_event(client, {"event": "S", "event_cnt": 2})
            time.sleep(60)
    except KeyboardInterrupt:
        logging.info("Interrupted, shutting down")
    finally:
        client.loop_stop()
        client.disconnect()

if __name__ == "__main__":
    main()
